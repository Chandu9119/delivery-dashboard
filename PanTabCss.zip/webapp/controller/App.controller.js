sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.pantabcssPanTabCss.controller.App", {

		onInit: function() {

			
			

			// var oModel = new sap.ui.model.json.JSONModel();
			// oModel.setData(oObject);
			// this.getView().byId("carTable").setModel(oModel);

		},
		
		
		onclick: function(){
			
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData("../../../../../../webapp/model/car.json");
			this.getView().byId("carTable").setModel(oModel,"localjson");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	});
});